`timescale 1ns / 1ps
module MAC #
(
parameter DATA_WIDTH = 8
)
(
input clk,
input rst_n,
input En,
input Clr,
input [DATA_WIDTH-1:0] Ain,
input [DATA_WIDTH-1:0] Bin,
output [DATA_WIDTH*3-1:0] Cout
);
// logic [DATA_WIDTH*3-1:0] Cout_in;
// assign Cout = Cout_in;
// always_ff @(posedge clk, negedge rst_n) begin
//     if (!rst_n) begin
//         Cout_in <= 0;
//     end
//     else if (Clr) begin
//         Cout_in <= 0;
//     end
//     else if (En) begin
//         Cout_in <= Cout_in + Ain * Bin;
//     end
// end
wire [15:0] rslt;

multiplier multiplier
(
	.dataa(Ain),
	.datab(Bin),
	.result(rslt)
);

Accumulator Accumulator
(
	.clken(&En),
	.clock(clk),
	.dataa({8'h00, rslt}),
	.datab(Cout),
	.result(Cout)
);

endmodule